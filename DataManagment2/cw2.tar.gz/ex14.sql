SELECT SUM(cases) as totalcases,
       SUM(deaths) as totaldeaths
From EventData;